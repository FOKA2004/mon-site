import 'package:flutter/material.dart';

void main() => runApp(AllBookApp());

class AllBookApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AllBook',
      home: Scaffold(
        appBar: AppBar(title: Text('AllBook')),
        body: Center(child: Text('Bienvenue dans AllBook')),
      ),
    );
  }
}
